Option Strict On
Option Explicit On 

' -------------------------------------------------------------------------------
' Written by Matthew Monroe for the Department of Energy (PNNL, Richland, WA)
' Upgraded to VB.NET from VB6 in October 2003
' Copyright 2005, Battelle Memorial Institute

' E-mail: matthew.monroe@pnl.gov or matt@alchemistmatt.com
' Website: http://ncrr.pnl.gov/ or http://www.sysbio.org/resources/staff/
' -------------------------------------------------------------------------------
' 
' Licensed under the Apache License, Version 2.0; you may not use this file except
' in compliance with the License.  You may obtain a copy of the License at 
' http://www.apache.org/licenses/LICENSE-2.0
'
' Notice: This computer software was prepared by Battelle Memorial Institute, 
' hereinafter the Contractor, under Contract No. DE-AC05-76RL0 1830 with the 
' Department of Energy (DOE).  All rights in the computer software are reserved 
' by DOE on behalf of the United States Government and the Contractor as 
' provided in the Contract.  NEITHER THE GOVERNMENT NOR THE CONTRACTOR MAKES ANY 
' WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS 
' SOFTWARE.  This notice including this sentence must appear on any copies of 
' this computer software.

<System.Runtime.InteropServices.ProgId("Spectrum_NET.Spectrum")> Public Class Spectrum

    Private Const SPECTRUM_DLL_DATE As String = "October 5, 2005"

    ''Public Enum pmPlotModeConstants
    ''	pmLines = 0
    ''	pmStickToZero = 1
    ''	pmBar = 2
    ''	pmPoints = 3
    ''	pmPointsAndLines = 4
    ''End Enum

    ''Public Enum asmAnnotationSnapModeConstants
    ''	asmFixedToAnyPoint = 0
    ''	asmFixedToSingleDataPoint = 1
    ''	asmFloating = 2
    ''End Enum

    Public Structure udtAutoLabelPeaksOptionsType
        Public IsContinuousData As Boolean ' When False, means Is Discrete Data
        Public DisplayXPos As Boolean
        Public DisplayYPos As Boolean
        Public IncludeArrow As Boolean
        Public HideInDenseRegions As Boolean
        Public CaptionAngle As Integer
        Public IntensityThresholdMinimum As Double
        Public MinimumIntensityPercentageOfMaximum As Integer
        Public PeakWidthMinimumPoints As Integer
        Public PeakLabelCountMaximum As Integer
    End Structure

    ' Client notification event
    Public Event SpectrumFormRequestClose()

    ' Actual spectrum form
    Private WithEvents SpectrumForm As frmCWSpectrum
    Private mSpectrumLoaded As Boolean
    '

    Public Sub AutoLabelPeaks(ByRef intSeriesNumber As Short, ByRef blnShowXPos As Boolean, ByRef blnShowYPos As Boolean, Optional ByRef lngCaptionAngle As Integer = 0, Optional ByRef blnIncludeArrow As Boolean = False, Optional ByRef blnHideInDenseRegions As Boolean = True, Optional ByRef lngMaxPeakCount As Integer = 100, Optional ByRef blnForceAsContinuousData As Boolean = False, Optional ByRef blnForceAsDiscreteData As Boolean = False)
        SpectrumForm.ctlCWGraph.AutoLabelPeaks(intSeriesNumber, blnShowXPos, blnShowYPos, lngCaptionAngle, blnIncludeArrow, blnHideInDenseRegions, lngMaxPeakCount, blnForceAsContinuousData, blnForceAsDiscreteData)
    End Sub

    Public Sub AutoScaleVisibleYNow()
        SpectrumForm.ctlCWGraph.AutoScaleVisibleYNow()
    End Sub

    Public Sub AutoScaleXNow()
        SpectrumForm.ctlCWGraph.AutoScaleXNow()
    End Sub

    Public Sub AutoScaleYNow()
        SpectrumForm.ctlCWGraph.AutoScaleYNow()
    End Sub

    Public Sub CenterCursors(Optional ByVal intCursorNumber As Integer = 1, Optional ByVal blncenterAll As Boolean = True)
        SpectrumForm.ctlCWGraph.CenterCursor(intCursorNumber, blncenterAll)
    End Sub

    Public Sub ClearData(ByRef intSeriesToClear As Short)
        ' This does not prompt the user
        SpectrumForm.ctlCWGraph.ClearData(intSeriesToClear)
    End Sub

    Public Sub ClearDataAllSeries()
        ' This does not prompt the user
        SpectrumForm.DeleteDataForAllSeries(False)
    End Sub

    Public Sub CopyDataPointsToClipboardOrToString(ByRef intSeriesNumber As Short, Optional ByRef strDataToCopy As String = "", Optional ByVal strDelim As String = vbTab, Optional ByVal blnCopyToClipboard As Boolean = True)
        ' If blnCopyToClipboard = False, then simply populates strDataToCopy

        SpectrumForm.CopyDataPointsToClipboardOrToString(intSeriesNumber, strDataToCopy, strDelim, blnCopyToClipboard)
    End Sub

    Public Sub CopyToClipboardAsPicture()
        SpectrumForm.CopyToClipboardAsPicture()
    End Sub

    Public Property DateModeXAxis() As Boolean
        Get
            Return SpectrumForm.ctlCWGraph.DateModeXAxis
        End Get
        Set(ByVal Value As Boolean)
            SpectrumForm.ctlCWGraph.DateModeXAxis = Value
        End Set
    End Property

    Public Property DateModeXAxisShowTime() As Boolean
        Get
            Return SpectrumForm.ctlCWGraph.DateModeXAxisShowTime
        End Get
        Set(ByVal Value As Boolean)
            SpectrumForm.ctlCWGraph.DateModeXAxisShowTime = Value
        End Set
    End Property

    Public Sub DeleteDataActiveSeries(Optional ByRef blnConfirmDeletion As Boolean = True)
        SpectrumForm.DeleteDataActiveSeries(blnConfirmDeletion)
    End Sub

    Public Sub DeleteDataForAllSeries(Optional ByRef blnConfirmDeletion As Boolean = True)
        SpectrumForm.DeleteDataForAllSeries(blnConfirmDeletion)
    End Sub

    Public Sub EnableTrackAnnotationPlacement()
        SpectrumForm.ctlCWGraph.EnableTrackAnnotationPlacement()
    End Sub

    Public Sub EnableTrackCursor()
        SpectrumForm.ctlCWGraph.EnableTrackCursor()
    End Sub

    Public Sub EnableTrackModeAllEvents()
        SpectrumForm.ctlCWGraph.EnableTrackModeAllEvents()
    End Sub

    Public Sub EnableTrackModePan(Optional ByRef blnPanXOnly As Boolean = False, Optional ByRef blnPanYOnly As Boolean = False)
        SpectrumForm.ctlCWGraph.EnableTrackModePan(blnPanXOnly, blnPanYOnly)
    End Sub

    Public Sub EnableTrackModeZoom(Optional ByRef blnZoomXOnly As Boolean = False, Optional ByRef blnZoomYOnly As Boolean = False)
        SpectrumForm.ctlCWGraph.EnableTrackModeZoom(blnZoomXOnly, blnZoomYOnly)
    End Sub

    Public Sub GenerateSineWave(ByRef intSeriesNumber As Short, ByRef blnXAxisLogBased As Boolean)
        SpectrumForm.ctlCWGraph.GenerateSineWave(intSeriesNumber, blnXAxisLogBased)
    End Sub

    Public Function GetAnnotationFontColor(ByRef intSeriesIndex As Short) As System.Drawing.Color
        GetAnnotationFontColor = SpectrumForm.ctlCWGraph.GetAnnotationFontColor(intSeriesIndex)
    End Function

    Public Function GetAnnotationFontName(ByRef intSeriesIndex As Short) As String
        GetAnnotationFontName = SpectrumForm.ctlCWGraph.GetAnnotationFontName(intSeriesIndex)
    End Function

    Public Function GetAnnotationFontSize(ByRef intSeriesIndex As Short) As Short
        GetAnnotationFontSize = SpectrumForm.ctlCWGraph.GetAnnotationFontSize(intSeriesIndex)
    End Function

    Public Function GetAnnotationDensityToleranceAutoAdjust() As Boolean
        GetAnnotationDensityToleranceAutoAdjust = SpectrumForm.ctlCWGraph.GetAnnotationDensityToleranceAutoAdjust()
    End Function

    Public Function GetAnnotationDensityToleranceX() As Double
        GetAnnotationDensityToleranceX = SpectrumForm.ctlCWGraph.GetAnnotationDensityToleranceX()
    End Function

    Public Function GetAnnotationDensityToleranceY() As Double
        GetAnnotationDensityToleranceY = SpectrumForm.ctlCWGraph.GetAnnotationDensityToleranceY()
    End Function

    Public Function GetAnnotationCount() As Short
        GetAnnotationCount = SpectrumForm.ctlCWGraph.GetAnnotationCount()
    End Function

    Public Function GenerateAnnotationUsingNearestPoint(ByRef dblCaptionXPos As Double, ByRef dblCaptionYPos As Double, ByRef intSeriesNumber As Short, ByRef blnAnnotationShowsNearestPointX As Boolean, ByRef blnAnnotationShowsNearestPointY As Boolean, ByRef blnBindToPoint As Boolean, ByRef strCurrentCaption As String, Optional ByRef lngPointNumberOverride As Integer = -1) As String
        GenerateAnnotationUsingNearestPoint = SpectrumForm.ctlCWGraph.GenerateAnnotationUsingNearestPoint(dblCaptionXPos, dblCaptionYPos, intSeriesNumber, blnAnnotationShowsNearestPointX, blnAnnotationShowsNearestPointY, blnBindToPoint, strCurrentCaption, lngPointNumberOverride)
    End Function

    Public Function GetAnnotationDensityAutoHideCaptions() As Boolean
        GetAnnotationDensityAutoHideCaptions = SpectrumForm.ctlCWGraph.GetAnnotationDensityAutoHideCaptions()
    End Function


    Public Function GetAnnotationByIndex(ByVal lngAnnotationIndex As Integer, ByRef CaptionXPos As Double, ByRef CaptionYPos As Double, ByRef strCaptionText As String, Optional ByRef lngCaptionAngle As Integer = 0, Optional ByRef intSeriesNumber As Short = 0, Optional ByRef eAnnotationSnapMode As CWGraphControl.asmAnnotationSnapModeConstants = CWGraphControl.asmAnnotationSnapModeConstants.asmFixedToAnyPoint, Optional ByRef lngPointNumberToBind As Integer = 0, Optional ByRef blnAnnotationShowsNearestPointX As Boolean = False, Optional ByRef blnAnnotationShowsNearestPointY As Boolean = False, Optional ByRef blnIncludeArrow As Boolean = False, Optional ByRef blnHideInDenseRegions As Boolean = False, Optional ByRef strAnnotationNameReturn As String = "") As Boolean
        GetAnnotationByIndex = SpectrumForm.ctlCWGraph.GetAnnotationByIndex(lngAnnotationIndex, CaptionXPos, CaptionYPos, strCaptionText, lngCaptionAngle, intSeriesNumber, eAnnotationSnapMode, lngPointNumberToBind, blnAnnotationShowsNearestPointX, blnAnnotationShowsNearestPointY, blnIncludeArrow, blnHideInDenseRegions, strAnnotationNameReturn)
    End Function

    Public Function GetAnnotationByName(ByVal strAnnotationName As String, ByRef CaptionXPos As Double, ByRef CaptionYPos As Double, ByRef strCaptionText As String, Optional ByRef lngCaptionAngle As Integer = 0, Optional ByRef intSeriesNumber As Short = 0, Optional ByRef eAnnotationSnapMode As CWGraphControl.asmAnnotationSnapModeConstants = CWGraphControl.asmAnnotationSnapModeConstants.asmFixedToAnyPoint, Optional ByRef lngPointNumberToBind As Integer = 0, Optional ByRef blnAnnotationShowsNearestPointX As Boolean = False, Optional ByRef blnAnnotationShowsNearestPointY As Boolean = False, Optional ByRef blnIncludeArrow As Boolean = False, Optional ByRef blnHideInDenseRegions As Boolean = False, Optional ByRef strAnnotationNameReturn As String = "", Optional ByRef blnCaseSensitive As Boolean = False) As Boolean
        GetAnnotationByName = SpectrumForm.ctlCWGraph.GetAnnotationByName(strAnnotationName, CaptionXPos, CaptionYPos, strCaptionText, lngCaptionAngle, intSeriesNumber, eAnnotationSnapMode, lngPointNumberToBind, blnAnnotationShowsNearestPointX, blnAnnotationShowsNearestPointY, blnIncludeArrow, blnHideInDenseRegions, strAnnotationNameReturn, blnCaseSensitive)
    End Function

    Public Function GetAutoAdjustScalingToIncludeCaptions() As Boolean
        GetAutoAdjustScalingToIncludeCaptions = SpectrumForm.ctlCWGraph.GetAutoAdjustScalingToIncludeCaptions()
    End Function

    Public Sub GetAutoLabelPeaksOptions(ByRef udtAutoLabelPeaksOptions As udtAutoLabelPeaksOptionsType)

        Dim udtAutoLabelPeaksOptionsInternal As udtAutoLabelPeaksOptionsInternalType

        SpectrumForm.StoreAutoLabelPeaksOptionsInModule()
        AutoLabelOptionsRetrieve(udtAutoLabelPeaksOptionsInternal)

        With udtAutoLabelPeaksOptionsInternal
            udtAutoLabelPeaksOptions.CaptionAngle = .CaptionAngle
            udtAutoLabelPeaksOptions.DisplayXPos = .DisplayXPos
            udtAutoLabelPeaksOptions.DisplayYPos = .DisplayYPos
            udtAutoLabelPeaksOptions.HideInDenseRegions = .HideInDenseRegions
            udtAutoLabelPeaksOptions.IncludeArrow = .IncludeArrow
            udtAutoLabelPeaksOptions.IntensityThresholdMinimum = .IntensityThresholdMinimum
            If .DataMode = modCWSpectrum.dmDataModeConstants.dmContinuous Then
                udtAutoLabelPeaksOptions.IsContinuousData = True
            Else
                udtAutoLabelPeaksOptions.IsContinuousData = False
            End If
            udtAutoLabelPeaksOptions.MinimumIntensityPercentageOfMaximum = .MinimumIntensityPercentageOfMaximum
            udtAutoLabelPeaksOptions.PeakLabelCountMaximum = .PeakLabelCountMaximum
            udtAutoLabelPeaksOptions.PeakWidthMinimumPoints = .PeakWidthMinimumPoints
        End With

    End Sub

    Public Function GetAutoscaleVisibleY() As Boolean
        GetAutoscaleVisibleY = SpectrumForm.ctlCWGraph.GetAutoscaleVisibleY()
    End Function

    Public Function GetControlImage() As System.Drawing.Image
        ' Returns an image of the graph, in the form of a Windows MetaFile
        GetControlImage = SpectrumForm.ctlCWGraph.GetControlImage()
    End Function

    Public Function GetCursorSnapToDataPointModeEnabled() As Boolean
        GetCursorSnapToDataPointModeEnabled = SpectrumForm.ctlCWGraph.GetCursorSnapToDataPointModeEnabled()
    End Function

    Public Function GetCursorColor(Optional ByVal intCursorNumber As Integer = 1) As System.Drawing.Color
        GetCursorColor = SpectrumForm.ctlCWGraph.GetCursorColor(intCursorNumber)
    End Function

    Public Sub GetCursorPosition(ByRef XPos As Double, ByRef YPos As Double, Optional ByVal intCursorNumber As Integer = 1)
        SpectrumForm.ctlCWGraph.GetCursorPosition(XPos, YPos, intCursorNumber)
    End Sub

    Public Function GetCursorVisibility(Optional ByVal intCursorNumber As Integer = 1) As Boolean
        GetCursorVisibility = SpectrumForm.ctlCWGraph.GetCursorVisibility(intCursorNumber)
    End Function

    Public Function GetDataCount(ByVal intSeriesNumber As Short) As Integer
        GetDataCount = SpectrumForm.ctlCWGraph.GetDataCount(intSeriesNumber)
    End Function

    Public Function GetDataXvsY(ByVal intSeriesNumber As Short, ByRef XDataZeroBased1DArray() As Double, ByRef YDataZeroBased1DArray() As Double, ByRef DataCount As Integer) As Boolean
        GetDataXvsY = SpectrumForm.ctlCWGraph.GetDataXvsY(intSeriesNumber, XDataZeroBased1DArray, YDataZeroBased1DArray, DataCount)
    End Function

    Public Function GetDefaulSeriesColor(ByRef intSeriesNumber As Short) As System.Drawing.Color
        GetDefaulSeriesColor = SpectrumForm.ctlCWGraph.GetDefaulSeriesColor(intSeriesNumber)
    End Function

    Public Function GetDisplayPrecisionX() As Double
        GetDisplayPrecisionX = SpectrumForm.ctlCWGraph.GetDisplayPrecisionX()
    End Function

    Public Function GetDisplayPrecisionY() As Double
        GetDisplayPrecisionY = SpectrumForm.ctlCWGraph.GetDisplayPrecisionY()
    End Function

    Public Function GetFixMinimumYAtZero() As Boolean
        GetFixMinimumYAtZero = SpectrumForm.ctlCWGraph.GetFixMinimumYAtZero()
    End Function

    Public Function GetLabelFontColor() As System.Drawing.Color
        GetLabelFontColor = SpectrumForm.ctlCWGraph.GetLabelFontColor()
    End Function

    Public Function GetLabelFontName() As String
        GetLabelFontName = SpectrumForm.ctlCWGraph.GetLabelFontName()
    End Function

    Public Function GetLabelFontSize() As Short
        GetLabelFontSize = SpectrumForm.ctlCWGraph.GetLabelFontSize()
    End Function

    Public Function GetGridLinesXVisible(Optional ByRef blnMajorGridLines As Boolean = True) As Boolean
        GetGridLinesXVisible = SpectrumForm.ctlCWGraph.GetGridLinesXVisible(blnMajorGridLines)
    End Function

    Public Function GetGridlinesYVisible(Optional ByRef blnMajorGridLines As Boolean = True) As Boolean
        GetGridlinesYVisible = SpectrumForm.ctlCWGraph.GetGridlinesYVisible(blnMajorGridLines)
    End Function

    Public Function GetGridLinesXColor(Optional ByRef blnMajorGridLines As Boolean = True) As System.Drawing.Color
        GetGridLinesXColor = SpectrumForm.ctlCWGraph.GetGridLinesXColor(blnMajorGridLines)
    End Function

    Public Function GetGridLinesYColor(Optional ByRef blnMajorGridLines As Boolean = True) As System.Drawing.Color
        GetGridLinesYColor = SpectrumForm.ctlCWGraph.GetGridLinesYColor(blnMajorGridLines)
    End Function

    Public Function GetLabelSubtitle() As String
        GetLabelSubtitle = SpectrumForm.ctlCWGraph.GetLabelSubtitle()
    End Function

    Public Function GetLabelTitle() As String
        GetLabelTitle = SpectrumForm.ctlCWGraph.GetLabelTitle()
    End Function

    Public Function GetLabelXAxis() As String
        GetLabelXAxis = SpectrumForm.ctlCWGraph.GetLabelXAxis()
    End Function

    Public Function GetLabelYAxis() As String
        GetLabelYAxis = SpectrumForm.ctlCWGraph.GetLabelYAxis()
    End Function

    Public Function GetPlotBackgroundColor() As System.Drawing.Color
        GetPlotBackgroundColor = SpectrumForm.ctlCWGraph.GetPlotBackgroundColor()
    End Function

    Public Function GetRangeX(Optional ByRef dblMinimum As Double = 0, Optional ByRef dblMaximum As Double = 0) As Double
        ' Returns Abs(dblMaximum - dblMinimum)
        GetRangeX = SpectrumForm.ctlCWGraph.GetRangeX(dblMinimum, dblMaximum)
    End Function

    Public Function GetRangeY(Optional ByRef dblMinimum As Double = 0, Optional ByRef dblMaximum As Double = 0) As Double
        ' Returns Abs(dblMaximum - dblMinimum)
        GetRangeY = SpectrumForm.ctlCWGraph.GetRangeY(dblMinimum, dblMaximum)
    End Function

    Public Function GetSeriesBarFillColor(ByRef intSeriesNumber As Short) As System.Drawing.Color
        GetSeriesBarFillColor = SpectrumForm.ctlCWGraph.GetSeriesBarFillColor(intSeriesNumber)
    End Function

    Public Function GetSeriesCount() As Integer
        GetSeriesCount = SpectrumForm.ctlCWGraph.GetSeriesCount()
    End Function

    Public Function GetSeriesLegendCaption(ByRef intSeriesNumber As Short) As String
        GetSeriesLegendCaption = SpectrumForm.ctlCWGraph.GetSeriesLegendCaption(intSeriesNumber)
    End Function

    Public Function GetSeriesLineColor(ByRef intSeriesNumber As Short) As System.Drawing.Color
        GetSeriesLineColor = SpectrumForm.ctlCWGraph.GetSeriesLineColor(intSeriesNumber)
    End Function

    Public Function GetSeriesLineToBaseColor(ByRef intSeriesNumber As Short) As System.Drawing.Color
        GetSeriesLineToBaseColor = SpectrumForm.ctlCWGraph.GetSeriesLineToBaseColor(intSeriesNumber)
    End Function

    Public Function GetSeriesLineStyle(ByRef intSeriesNumber As Short) As CWUIControlsLib.CWLineStyles
        GetSeriesLineStyle = SpectrumForm.ctlCWGraph.GetSeriesLineStyle(intSeriesNumber)
    End Function

    Public Function GetSeriesLineWidth(ByRef intSeriesNumber As Short) As Short
        GetSeriesLineWidth = SpectrumForm.ctlCWGraph.GetSeriesLineWidth(intSeriesNumber)
    End Function

    Public Function GetSeriesOriginalIntensityMaximum(ByRef intSeriesNumber As Short) As Double
        GetSeriesOriginalIntensityMaximum = SpectrumForm.ctlCWGraph.GetSeriesOriginalIntensityMaximum(intSeriesNumber)
    End Function

    Public Function GetSeriesPlotMode(ByRef intSeriesNumber As Short) As CWGraphControl.pmPlotModeConstants
        GetSeriesPlotMode = SpectrumForm.ctlCWGraph.GetSeriesPlotMode(intSeriesNumber)
    End Function

    Public Function GetSeriesPointColor(ByRef intSeriesNumber As Short) As System.Drawing.Color
        GetSeriesPointColor = SpectrumForm.ctlCWGraph.GetSeriesPointColor(intSeriesNumber)
    End Function

    Public Function GetSeriesPointStyle(ByRef intSeriesNumber As Short) As CWUIControlsLib.CWPointStyles
        GetSeriesPointStyle = SpectrumForm.ctlCWGraph.GetSeriesPointStyle(intSeriesNumber)
    End Function

    Public Function GetSpectrumFormActiveSeriesNumber() As Short
        GetSpectrumFormActiveSeriesNumber = SpectrumForm.GetActiveSeriesNumber()
    End Function

    Public Function GetSpectrumFormNormalizeOnLoadOrPaste() As Boolean
        GetSpectrumFormNormalizeOnLoadOrPaste = SpectrumForm.GetNormalizeOnLoadOrPaste()
    End Function

    Public Function GetSpectrumFormNormalizationConstant() As Double
        GetSpectrumFormNormalizationConstant = SpectrumForm.GetNormalizationConstant()
    End Function

    Public Sub GetSpectrumFormWindowPos(ByRef Top As Integer, ByRef intLeft As Integer, ByRef Height As Integer, ByRef Width As Integer)
        SpectrumForm.GetWindowPos(Top, intLeft, Height, Width)
    End Sub

    Public Sub LoadDataFromDisk(Optional ByRef strInputFilePath As String = "", Optional ByRef blnShowMessages As Boolean = True, Optional ByRef blnLoadOptionsOnly As Boolean = False, Optional ByRef blnDelimeterComma As Boolean = True, Optional ByRef blnDelimeterTab As Boolean = True, Optional ByRef blnDelimeterSpace As Boolean = False, Optional ByRef blnLoadingDTAFile As Boolean = False)
        SpectrumForm.LoadDataFromDisk(strInputFilePath, blnShowMessages, blnLoadOptionsOnly, blnDelimeterComma, blnDelimeterTab, blnDelimeterSpace, blnLoadingDTAFile)
    End Sub

    Public Function LookupNearestPointNumber(ByVal dblXPosSearch As Double, ByVal dblYPosSearch As Double, ByRef intSeriesNumber As Short, Optional ByRef dblDistanceToClosestSeriesNumberDataPoint As Double = 0, Optional ByVal blnLimitToGivenSeriesNumber As Boolean = False) As Integer
        LookupNearestPointNumber = SpectrumForm.ctlCWGraph.LookupNearestPointNumber(dblXPosSearch, dblYPosSearch, intSeriesNumber, dblDistanceToClosestSeriesNumberDataPoint, blnLimitToGivenSeriesNumber)
    End Function

    Public Sub PasteDataFromClipboard(Optional ByRef blnShowMessages As Boolean = True, Optional ByRef blnAllowCommaDelimeter As Boolean = True)
        SpectrumForm.PasteDataFromClipboard(blnShowMessages, blnAllowCommaDelimeter)
    End Sub

    Public Function RemoveAnnotationByCaption(ByVal strAnnotationText As String, Optional ByRef blnCaseSensitive As Boolean = False) As Boolean
        RemoveAnnotationByCaption = SpectrumForm.ctlCWGraph.RemoveAnnotationByCaption(strAnnotationText, blnCaseSensitive)
    End Function

    Public Function RemoveAnnotationByIndex(ByRef lngAnnotationIndex As Integer) As Boolean
        RemoveAnnotationByIndex = SpectrumForm.ctlCWGraph.RemoveAnnotationByCaption(CStr(lngAnnotationIndex))
    End Function

    Public Sub RemoveAllAnnotations(Optional ByRef blnConfirmRemoval As Boolean = False)
        SpectrumForm.ctlCWGraph.RemoveAllAnnotations((blnConfirmRemoval))
    End Sub

    Public Sub RemoveAnnotationsForSeries(ByRef intSeriesNumber As Short)
        SpectrumForm.ctlCWGraph.RemoveAnnotationsForSeries(intSeriesNumber)
    End Sub

    Public Sub ResetOptionsToDefaults(Optional ByRef blnClearAllData As Boolean = False, Optional ByRef blnResetSeriesCount As Boolean = False, Optional ByRef intNewSeriesCount As Short = 2, Optional ByRef eDefaultPlotMode As CWGraphControl.pmPlotModeConstants = CWGraphControl.pmPlotModeConstants.pmLines)
        ' This does not prompt the user
        SpectrumForm.ctlCWGraph.ResetOptionsToDefaults(blnClearAllData, blnResetSeriesCount, intNewSeriesCount, eDefaultPlotMode)
    End Sub

    Public Sub SaveDataToDisk(Optional ByRef strOutputFilePath As String = "", Optional ByRef blnOptionsOnly As Boolean = False, Optional ByRef strDelim As String = ",", Optional ByRef blnShowMessages As Boolean = True, Optional ByRef blnAppendOptionsToFile As Boolean = False)
        SpectrumForm.SaveDataToDisk(strOutputFilePath, blnOptionsOnly, strDelim, blnShowMessages, blnAppendOptionsToFile)
    End Sub

    Public Sub SaveToDiskAsWMF(Optional ByRef strOutputFilePath As String = "", Optional ByRef blnShowMessages As Boolean = True)
        SpectrumForm.SaveToDiskAsPicture(strOutputFilePath, blnShowMessages)
    End Sub

    Public Function SetAnnotation(ByVal blnPromptForText As Boolean, ByRef CaptionXPos As Double, ByRef CaptionYPos As Double, Optional ByRef strCaptionText As String = "", Optional ByRef lngCaptionAngle As Integer = 0, Optional ByRef intSeriesNumber As Short = 1, Optional ByRef eAnnotationSnapMode As CWGraphControl.asmAnnotationSnapModeConstants = CWGraphControl.asmAnnotationSnapModeConstants.asmFixedToSingleDataPoint, Optional ByRef lngPointNumberToBind As Integer = -1, Optional ByRef blnAnnotationShowsNearestPointX As Boolean = False, Optional ByRef blnAnnotationShowsNearestPointY As Boolean = False, Optional ByRef blnIncludeArrow As Boolean = False, Optional ByRef blnHideInDenseRegions As Boolean = True, Optional ByRef lngAnnotationIndexForce As Integer = 0, Optional ByRef blnAutomaticCaptionPlacement As Boolean = False) As Integer
        ' Adds a new annotation
        '  or updates an existing one of lngAnnotationIndexForce is > 0
        ' Returns the index of the annotation (.Annotations is 1-based)
        ' Returns 0 if an annotation is removed or the change is cancelled
        ' Use lngAnnotationIndexForce to force editing of an existing annotation

        SetAnnotation = SpectrumForm.ctlCWGraph.SetAnnotation(blnPromptForText, CaptionXPos, CaptionYPos, strCaptionText, lngCaptionAngle, intSeriesNumber, eAnnotationSnapMode, lngPointNumberToBind, blnAnnotationShowsNearestPointX, blnAnnotationShowsNearestPointY, blnIncludeArrow, blnHideInDenseRegions, lngAnnotationIndexForce, blnAutomaticCaptionPlacement)
    End Function

    Public Function SetAnnotationByIndex(ByRef lngAnnotationIndex As Integer, ByRef CaptionXPos As Double, ByRef CaptionYPos As Double, Optional ByRef strCaptionText As String = "", Optional ByRef lngCaptionAngle As Integer = 0, Optional ByRef intSeriesNumber As Short = 1, Optional ByRef eAnnotationSnapMode As CWGraphControl.asmAnnotationSnapModeConstants = CWGraphControl.asmAnnotationSnapModeConstants.asmFixedToSingleDataPoint, Optional ByRef lngPointNumberToBind As Integer = 0, Optional ByRef blnAnnotationShowsNearestPointX As Boolean = False, Optional ByRef blnAnnotationShowsNearestPointY As Boolean = False, Optional ByRef blnIncludeArrow As Boolean = False, Optional ByRef blnHideInDenseRegions As Boolean = True, Optional ByRef blnAutomaticCaptionPlacement As Boolean = False, Optional ByRef strReturnAnnotationName As String = "") As Boolean
        SetAnnotationByIndex = SpectrumForm.ctlCWGraph.SetAnnotationByIndex(lngAnnotationIndex, CaptionXPos, CaptionYPos, strCaptionText, lngCaptionAngle, intSeriesNumber, eAnnotationSnapMode, lngPointNumberToBind, blnAnnotationShowsNearestPointX, blnAnnotationShowsNearestPointY, blnIncludeArrow, blnHideInDenseRegions, blnAutomaticCaptionPlacement, strReturnAnnotationName)
    End Function

    Public Sub SetAnnotationFontColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color, ByRef blnMakeDefaultForAll As Boolean)
        SpectrumForm.ctlCWGraph.SetAnnotationFontColor(intSeriesNumber, cNewColor, blnMakeDefaultForAll)
    End Sub

    Public Sub SetAnnotationFontName(ByRef intSeriesNumber As Short, ByRef strNewFontName As String, ByRef blnMakeDefaultForAll As Boolean)
        SpectrumForm.ctlCWGraph.SetAnnotationFontName(intSeriesNumber, strNewFontName, blnMakeDefaultForAll)
    End Sub

    Public Sub SetAnnotationFontSize(ByRef intSeriesNumber As Short, ByRef intNewSize As Short, ByRef blnMakeDefaultForAll As Boolean)
        SpectrumForm.ctlCWGraph.SetAnnotationFontSize(intSeriesNumber, intNewSize, blnMakeDefaultForAll)
    End Sub

    Public Sub SetAnnotationDensityAutoHideCaptions(ByRef blnEnableAutoHide As Boolean, Optional ByRef blnShowHiddenCaptionsIfDisabled As Boolean = True)
        SpectrumForm.ctlCWGraph.SetAnnotationDensityAutoHideCaptions(blnEnableAutoHide, blnShowHiddenCaptionsIfDisabled)
    End Sub

    Public Sub SetAnnotationDensityToleranceX(ByRef dblNewThreshold As Double)
        SpectrumForm.ctlCWGraph.SetAnnotationDensityToleranceX(dblNewThreshold)
    End Sub

    Public Sub SetAnnotationDensityToleranceY(ByRef dblNewThreshold As Double)
        SpectrumForm.ctlCWGraph.SetAnnotationDensityToleranceY(dblNewThreshold)
    End Sub

    Public Sub SetAnnotationDensityToleranceAutoAdjust(ByRef blnEnableAutoAdjust As Boolean)
        SpectrumForm.ctlCWGraph.SetAnnotationDensityToleranceAutoAdjust(blnEnableAutoAdjust)
    End Sub

    Public Sub SetAutoscaleXAxis(ByRef blnEnableAutoscale As Boolean)
        SpectrumForm.ctlCWGraph.SetAutoscaleXAxis(blnEnableAutoscale)
    End Sub

    Public Sub SetAutoscaleYAxis(ByRef blnEnableAutoscale As Boolean)
        SpectrumForm.ctlCWGraph.SetAutoscaleYAxis(blnEnableAutoscale)
    End Sub

    Public Sub SetAutoAdjustScalingToIncludeCaptions(ByRef blnEnable As Boolean)
        SpectrumForm.ctlCWGraph.SetAutoAdjustScalingToIncludeCaptions(blnEnable)
    End Sub

    Public Sub SetAutoLabelPeaksOptions(ByRef udtNewAutoLabelOptions As udtAutoLabelPeaksOptionsType)
        Dim udtAutoLabelPeaksOptionsInternal As udtAutoLabelPeaksOptionsInternalType

        With udtNewAutoLabelOptions
            udtAutoLabelPeaksOptionsInternal.CaptionAngle = .CaptionAngle
            udtAutoLabelPeaksOptionsInternal.DisplayXPos = .DisplayXPos
            udtAutoLabelPeaksOptionsInternal.DisplayYPos = .DisplayYPos
            udtAutoLabelPeaksOptionsInternal.HideInDenseRegions = .HideInDenseRegions
            udtAutoLabelPeaksOptionsInternal.IncludeArrow = .IncludeArrow
            udtAutoLabelPeaksOptionsInternal.IntensityThresholdMinimum = .IntensityThresholdMinimum
            If .IsContinuousData Then
                udtAutoLabelPeaksOptionsInternal.DataMode = modCWSpectrum.dmDataModeConstants.dmContinuous
            Else
                udtAutoLabelPeaksOptionsInternal.DataMode = modCWSpectrum.dmDataModeConstants.dmDiscrete
            End If
            udtAutoLabelPeaksOptionsInternal.MinimumIntensityPercentageOfMaximum = .MinimumIntensityPercentageOfMaximum
            udtAutoLabelPeaksOptionsInternal.PeakLabelCountMaximum = .PeakLabelCountMaximum
            udtAutoLabelPeaksOptionsInternal.PeakWidthMinimumPoints = .PeakWidthMinimumPoints
        End With

        AutoLabelOptionsStore(udtAutoLabelPeaksOptionsInternal)
        SpectrumForm.RetrieveAutoLabelPeaksOptionsFromModule()

    End Sub

    Public Sub SetAutoscaleVisibleY(ByVal blnEnableAutoscale As Boolean, ByVal blnFixMinimumYAtZero As Boolean)
        SpectrumForm.ctlCWGraph.SetAutoscaleVisibleY(blnEnableAutoscale, blnFixMinimumYAtZero)
    End Sub

    Public Sub SetCursorColor(ByRef cNewColor As System.Drawing.Color, Optional ByVal intCursorNumber As Integer = 1)
        SpectrumForm.ctlCWGraph.SetCursorColor(cNewColor, intCursorNumber)
    End Sub

    Public Sub SetCursorPosition(ByRef XPos As Double, ByRef YPos As Double, Optional ByVal intCursorNumber As Integer = 1)
        SpectrumForm.ctlCWGraph.SetCursorPosition(XPos, YPos, intCursorNumber)
    End Sub

    Public Sub SetCursorSnapMode(ByRef blnSnapToData As Boolean)
        SpectrumForm.ctlCWGraph.SetCursorSnapMode(blnSnapToData)
    End Sub

    Public Sub SetCursorVisible(ByRef blnShowCursor As Boolean, Optional ByVal intCursorNumber As Integer = 1)
        SpectrumForm.ctlCWGraph.SetCursorVisible(blnShowCursor, intCursorNumber)
    End Sub

    Public Sub SetDataXvsY(ByRef intSeriesNumber As Short, ByRef XDataZeroBased1DArray() As Double, ByRef YDataZeroBased1DArray() As Double, ByRef DataCount As Integer, Optional ByRef strLegendCaption As String = "", Optional ByRef dblOriginalMaximumIntensity As Double = 0)
        SpectrumForm.ctlCWGraph.SetDataXvsY(intSeriesNumber, XDataZeroBased1DArray, YDataZeroBased1DArray, DataCount, strLegendCaption, dblOriginalMaximumIntensity)
    End Sub

    Public Sub SetDataYOnly(ByRef intSeriesNumber As Short, ByRef YDataZeroBased1DArray() As Double, ByRef YDataCount As Integer, Optional ByRef dblXFirst As Double = 0, Optional ByRef dblIncrement As Double = 1, Optional ByRef strLegendCaption As String = "", Optional ByRef dblOriginalMaximumIntensity As Double = 0)
        SpectrumForm.ctlCWGraph.SetDataYOnly(intSeriesNumber, YDataZeroBased1DArray, YDataCount, dblXFirst, dblIncrement, strLegendCaption, dblOriginalMaximumIntensity)
    End Sub

    Public Sub SetDisplayPrecisionX(ByRef intPrecision As Short)
        SpectrumForm.ctlCWGraph.SetDisplayPrecisionX(intPrecision)
    End Sub

    Public Sub SetDisplayPrecisionY(ByRef intPrecision As Short)
        SpectrumForm.ctlCWGraph.SetDisplayPrecisionY(intPrecision)
    End Sub

    Public Sub SetGridLinesXColor(ByRef cNewColor As System.Drawing.Color, Optional ByRef blnMajorGridLines As Boolean = True, Optional ByRef blnApplyToAllAxes As Boolean = False, Optional ByRef blnUpdateTickColors As Boolean = True)
        SpectrumForm.ctlCWGraph.SetGridLinesXColor(cNewColor, blnMajorGridLines, blnApplyToAllAxes, blnUpdateTickColors)
    End Sub

    Public Sub SetGridLinesYColor(ByRef cNewColor As System.Drawing.Color, Optional ByRef blnMajorGridLines As Boolean = True, Optional ByRef blnApplyToAllAxes As Boolean = False, Optional ByRef blnUpdateTickColors As Boolean = True)
        SpectrumForm.ctlCWGraph.SetGridLinesYColor(cNewColor, blnMajorGridLines, blnApplyToAllAxes, blnUpdateTickColors)
    End Sub

    Public Sub SetGridLinesXVisible(ByRef blnShowGridLines As Boolean, Optional ByRef blnMajorGridLines As Boolean = True, Optional ByRef blnApplyToAllAxes As Boolean = False)
        SpectrumForm.ctlCWGraph.SetGridLinesXVisible(blnShowGridLines, blnMajorGridLines, blnApplyToAllAxes)
    End Sub

    Public Sub SetGridLinesYVisible(ByRef blnShowGridLines As Boolean, Optional ByRef blnMajorGridLines As Boolean = True, Optional ByRef blnApplyToAllAxes As Boolean = False)
        SpectrumForm.ctlCWGraph.SetGridLinesYVisible(blnShowGridLines, blnMajorGridLines, blnApplyToAllAxes)
    End Sub

    Public Sub SetLabelFontColor(ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetLabelFontColor(cNewColor)
    End Sub

    Public Sub SetLabelFontName(ByRef strFontName As String)
        SpectrumForm.ctlCWGraph.SetLabelFontName(strFontName)
    End Sub

    Public Sub SetLabelFontSize(ByRef intNewSize As Short)
        SpectrumForm.ctlCWGraph.SetLabelFontSize(intNewSize)
    End Sub

    Public Sub SetLabelXAxis(ByRef strAxisLabel As String)
        SpectrumForm.ctlCWGraph.SetLabelXAxis(strAxisLabel)
    End Sub

    Public Sub SetLabelYAxis(ByRef strAxisLabel As String)
        SpectrumForm.ctlCWGraph.SetLabelYAxis(strAxisLabel)
    End Sub

    Public Sub SetLabelTitle(ByRef strTitle As String)
        SpectrumForm.ctlCWGraph.SetLabelTitle(strTitle)
    End Sub

    Public Sub SetLabelSubTitle(ByRef strSubTitle As String)
        SpectrumForm.ctlCWGraph.SetLabelSubTitle(strSubTitle)
    End Sub

    Public Sub SetPlotBackgroundColor(ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetPlotBackgroundColor(cNewColor)
    End Sub

    Public Sub SetRangeX(ByRef dblMinimum As Double, ByRef dblMaximum As Double, Optional ByRef blnAddToZoomHistory As Boolean = True, Optional ByRef blnReturnAnnotationVisibilityChecked As Boolean = False)
        SpectrumForm.ctlCWGraph.SetRangeX(dblMinimum, dblMaximum, blnAddToZoomHistory, blnReturnAnnotationVisibilityChecked)
    End Sub

    Public Sub SetRangeY(ByRef dblMinimum As Double, ByRef dblMaximum As Double, Optional ByRef blnAddToZoomHistory As Boolean = True, Optional ByRef blnReturnAnnotationVisibilityChecked As Boolean = False)
        SpectrumForm.ctlCWGraph.SetRangeY(dblMinimum, dblMaximum, blnAddToZoomHistory, blnReturnAnnotationVisibilityChecked)
    End Sub

    Public Sub SetSeriesBarFillColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetSeriesBarFillColor(intSeriesNumber, cNewColor)
    End Sub

    Public Sub SetSeriesColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetSeriesColor(intSeriesNumber, cNewColor)
    End Sub

    Public Sub SetSeriesCount(ByRef intCount As Short)
        SpectrumForm.ctlCWGraph.SetSeriesCount(intCount)
    End Sub

    Public Sub SetSeriesLegendCaption(ByRef intSeriesNumber As Short, ByRef strNewCaption As String)
        SpectrumForm.ctlCWGraph.SetSeriesLegendCaption(intSeriesNumber, strNewCaption)
    End Sub

    Public Sub SetSeriesLineColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetSeriesLineColor(intSeriesNumber, cNewColor)
    End Sub

    Public Sub SetSeriesLineToBaseColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetSeriesLineToBaseColor(intSeriesNumber, cNewColor)
    End Sub

    Public Sub SetSeriesLineStyle(ByRef intSeriesNumber As Short, ByRef eLineStyle As CWUIControlsLib.CWLineStyles)
        SpectrumForm.ctlCWGraph.SetSeriesLineStyle(intSeriesNumber, eLineStyle)
    End Sub

    Public Sub SetSeriesLineWidth(ByRef intSeriesNumber As Short, ByRef intWidth As Short)
        SpectrumForm.ctlCWGraph.SetSeriesLineWidth(intSeriesNumber, intWidth)
    End Sub

    Public Sub SetSeriesOriginalIntensityMaximum(ByRef intSeriesNumber As Short, ByRef dblNewOriginalMaximumIntensity As Double)
        SpectrumForm.ctlCWGraph.SetSeriesOriginalIntensityMaximum(intSeriesNumber, dblNewOriginalMaximumIntensity)
    End Sub

    Public Sub SetSeriesPlotMode(ByRef intSeriesNumber As Short, ByRef ePlotMode As CWGraphControl.pmPlotModeConstants, ByRef blnMakeDefault As Boolean)
        SpectrumForm.ctlCWGraph.SetSeriesPlotMode(intSeriesNumber, ePlotMode, blnMakeDefault)
    End Sub

    Public Sub SetSeriesPointColor(ByRef intSeriesNumber As Short, ByRef cNewColor As System.Drawing.Color)
        SpectrumForm.ctlCWGraph.SetSeriesPointColor(intSeriesNumber, cNewColor)
    End Sub

    Public Sub SetSeriesPointStyle(ByRef intSeriesNumber As Short, ByRef ePointStyle As CWUIControlsLib.CWPointStyles)
        SpectrumForm.ctlCWGraph.SetSeriesPointStyle(intSeriesNumber, ePointStyle)
    End Sub

    Public Sub SetSeriesStartAndIncrement(ByRef intSeriesNumber As Short, ByRef dblXFirst As Double, ByRef dblIncrement As Double)
        SpectrumForm.ctlCWGraph.SetSeriesStartAndIncrement(intSeriesNumber, dblXFirst, dblIncrement)
    End Sub

    Public Sub SetSeriesVisible(ByRef intSeriesNumber As Short, ByRef blnShowSeries As Boolean)
        SpectrumForm.ctlCWGraph.SetSeriesVisible(intSeriesNumber, blnShowSeries)
    End Sub

    Public Sub SetSpectrumFormCurrentSeriesNumber(ByRef intSeriesNumber As Short)
        SpectrumForm.SetCurrentSeriesNumber(intSeriesNumber)
    End Sub

    Public Sub SetSpectrumFormNormalizeOnLoadOrPaste(ByRef blnEnable As Boolean)
        SpectrumForm.SetNormalizeOnLoadOrPaste(blnEnable)
    End Sub

    Public Sub SetSpectrumFormNormalizationConstant(ByRef dblNewNormalizationConstant As Double)
        SpectrumForm.SetNormalizationConstant(dblNewNormalizationConstant)
    End Sub

    Public Sub SetSpectrumFormWindowPos(ByRef Top As Integer, ByRef intLeft As Integer, ByRef Height As Integer, ByRef Width As Integer)
        SpectrumForm.SetWindowPos(Top, intLeft, Height, Width)
    End Sub

    Public Sub ShowAutoLabelPeaksDialog(Optional ByRef blnShowModal As Boolean = True)
        SpectrumForm.ShowAutoLabelPeaksDialog(blnShowModal)
    End Sub

    Public Sub ShowZoomRangeDialog()
        SpectrumForm.ShowZoomRangeDialog()
    End Sub

    Public Sub ShowHideControls(ByRef blnHideControlsFrame As Boolean)
        SpectrumForm.ctlCWGraph.ShowHideControls(blnHideControlsFrame)
    End Sub

    Public Sub ShowHideAnnotations(Optional ByRef blnForceOperation As Boolean = False)
        SpectrumForm.ctlCWGraph.ShowHideAnnotations(blnForceOperation)
    End Sub

    Public Sub InitializeSpectrum()
        ' Initialize SpectrumForm, if necessary
        If Not mSpectrumLoaded Then
            SpectrumForm = New frmCWSpectrum
            mSpectrumLoaded = True
        End If
    End Sub
    Public Sub ShowSpectrum()

        ' Make sure SpectrumForm is initialized
        InitializeSpectrum()

        ' Show ShowSpectrum
        SpectrumForm.Show()
    End Sub

    Public Sub UnloadSpectrum()
        ' Close SpectrumForm and unload it

        On Error Resume Next
        If mSpectrumLoaded Then
            SpectrumForm.Close()
            SpectrumForm = Nothing
            mSpectrumLoaded = False
        End If

    End Sub

    Public Sub UpdateAllDynamicAnnotationCaptions()
        SpectrumForm.ctlCWGraph.UpdateAllDynamicAnnotationCaptions()
    End Sub

    Public Sub ZoomOutFull(Optional ByRef blnAddToZoomHistory As Boolean = True, Optional ByRef blnAllowFixMinimumYAtZero As Boolean = True)
        SpectrumForm.ctlCWGraph.ZoomOutFull(blnAddToZoomHistory, blnAllowFixMinimumYAtZero)
    End Sub

    Public Sub ZoomToPrevious()
        SpectrumForm.ctlCWGraph.ZoomToPrevious()
    End Sub

    Public ReadOnly Property DllDate() As String
        Get
            DllDate = SPECTRUM_DLL_DATE
        End Get
    End Property

    Public ReadOnly Property DllVersion() As String
        Get
            Return System.Reflection.Assembly.GetCallingAssembly.GetName.Version.ToString
        End Get
    End Property

    Public ReadOnly Property AppDate() As String
        Get
            AppDate = SPECTRUM_DLL_DATE
        End Get
    End Property

    Public ReadOnly Property AppVersion() As String
        Get
            AppVersion = System.Windows.Forms.Application.ProductVersion
        End Get
    End Property

    Public Sub New()
        MyBase.New()
        InitializeSpectrum()
    End Sub

    Protected Overrides Sub Finalize()
        UnloadSpectrum()
        MyBase.Finalize()
    End Sub

    Private Sub SpectrumForm_SpectrumFormRequestClose() Handles SpectrumForm.SpectrumFormRequestClose
        RaiseEvent SpectrumFormRequestClose()
        If mSpectrumLoaded Then
            SpectrumForm.Hide()
        End If
    End Sub
End Class